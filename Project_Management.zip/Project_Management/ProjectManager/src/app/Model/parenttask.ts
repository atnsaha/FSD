﻿export class ParentTask{
    constructor(
        public Parent_ID: number,
        public ParentTaskName: string,
    )
    { }

}
