﻿export class User {
    constructor(
        public User_ID: number,
        public First_Name: string,
        public Last_Name: String,
        public Employee_ID: String,
        public Project_ID: number,
        public Task_ID: number
    ) { }
}