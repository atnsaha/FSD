﻿function closeModal() {
    $('#editTask').modal('toggle');
    return false;
}
function closeProjectModal() {
    $('#searchProject').modal('toggle');
    return false;
}
function closePTaskModal() {
    $('#searchParentTask').modal('toggle');
    return false;
}
function closeUserModal() {
    $('#searchUser').modal('toggle');
    return false;
}